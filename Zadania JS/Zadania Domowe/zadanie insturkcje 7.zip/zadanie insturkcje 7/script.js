console.log("Czesc");
const liczba =  Math.floor(Math.random() *15);

if (liczba >= 10)
{
    console.log("Witam Pani!");
}

else {
    console.log("Witam Pana!");
}

if (liczba >= 2)

{
    console.log("Chcesz wiedziec jaka jest pogoda?")
}

if(liczba >= 11){
    console.log("Z jakiego jestes kraju?")
}

else {
    console.log("Szkoda, to czesc")
}

if(liczba >= 15){
    console.log("Pogoda w Polsce jest cudowna")
}

else {
    console.log("Nie wiem gdzie lezy XXXX")
}

//zadanie 7 instukcje
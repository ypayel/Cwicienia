const liczba =  Math.floor(Math.random() *101);
const mysli =Number(prompt("O jakiej liczbe myslis?"));
if (mysli <= 10) {
    console.log("Goronco");
}
if(mysli <=30){
    console.log("Cieplo");
}
if (mysli <=60){
    console.log("Zimno");
}
if (mysli <=100){
    console.log("Lodowato")
}
// zadanie 23 petle